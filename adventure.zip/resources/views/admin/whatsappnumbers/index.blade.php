@extends('admin.layouts.app')
 
@section('title', 'Page Title')
 
@section('content')
<main>
    <div class="container mt-5">
        <h1>WhatsApp Numbers</h1>
        
        <form action="{{ route('admin.whatsappnumbers.store') }}" method="post">
            @csrf
            <!-- <label for="number">Enter WhatsApp Number:</label>
            <input type="number" name="number" id="number" required>
            <button type="submit">Add Number</button> -->
        </form>
        
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Number</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($whatsAppNumbers as $whatsAppNumber)
                <tr>
                    <td>{{ $whatsAppNumber->id }}</td>
                    <td>{{ $whatsAppNumber->number }}</td>
                    <td>
                        <form style="display: inline-block;" action="{{ route('admin.whatsappnumbers.edit', $whatsAppNumber->id) }}" method="GET">
                            @csrf
                            <button type="submit" class="btn btn-link">
                                <i class="fa fa-pencil fa-fw"></i> Edit
                            </button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</main>
 
@push('scripts')
@endpush
@endsection
