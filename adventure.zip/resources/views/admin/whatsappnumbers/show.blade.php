 

@extends('admin.layouts.app')
 
@section('title', 'Page Title')
 
@section('content')
    <div class="container">
    <h1>WhatsApp Number Details</h1>
    <table class="table table-striped">
             <thead>
                 <tr>
                     <th>ID</th>
                     <th>Number</th>
                      
                     <th>Actions</th>
                 </tr>
             </thead>
             <tbody>
             <tr>
                         <td>{{ $whatsAppNumber->id }}</td>
                         <td>{{ $whatsAppNumber->number }}</td>

 
<!-- <a href="{{ route('admin.whatsappnumbers.edit', $whatsAppNumber->id) }}" class="btn btn-primary">Edit</a>
    </div> -->
    <form style="display: inline-block;" action="{{ route('admin.whatsappnumbers.edit', $whatsAppNumber->id) }}" method="GET">
        @csrf
        <button type="submit" class="btn btn-link">
            <i class="fa fa-pencil fa-fw"></i> Edit
        </button>
    </form>
</td>
  </tr>
  

@push('scripts')

@endpush
@endsection
 