 

@extends('admin.layouts.app')
 
 @section('title', 'Page Title')
  
 @section('content')
     <div class="container">
     <h1>Hotel Bookings Details</h1>
     <table class="table table-striped">
              <thead>
                  <tr>
                  <th>ID</th>
                      <th>Hotel Id </th>
                      <th>Passenger Count</th>
                      
                      <th>Name</th>
                      <th>Total Price</th>
                      <th>Contact Name</th>
                      <th>Number</th>
                      <th>Email</th>
                      <th>Address</th>
                       
                       
                      <th>Actions</th>
                  </tr>
              </thead>
              <tbody>
              <tr> @foreach ($hotelBookings as $HotelBooking)
              <td>{{ $HotelBooking->id }}</td>
                          <td>{{ $HotelBooking->hotel_id }}</td>
                          <td>{{ $HotelBooking->passenger_count }}</td>
                           
                          <td>{{ $HotelBooking->name }}</td>
                          <td>{{ $HotelBooking->total_price }}</td>
                          <td>{{ $HotelBooking->contact_name }}</td>
                          
                          <td>{{ $HotelBooking->contact_phone_number }}</td>
                          <td>{{ $HotelBooking->contact_email }}</td>
                          <td>{{ $HotelBooking->contact_address }}</td>
                           
                          <td>
                          <form style="display: inline-block;" action="{{ url('admin/hotelbookings', $HotelBooking->id) }}" method="POST">
    @csrf
    @method('DELETE')

    <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this flight detail?')">
        <i class="fa fa-trash"></i> Delete
    </button>
</form>


   
    </td></td>
  </tr>
                 @endforeach
             </tbody>
         </table>
     </div>
 
 @push('scripts')
 
 @endpush
 @endsection
  