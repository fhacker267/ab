

@extends('admin.layouts.app')
 
@section('title', 'Page Title')
 
@section('content')
   
<div class="container">
    <h1>Edit Flight</h1>
    <form action="{{ route('admin.packages.update', ['package' => $package->id]) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="name">name:</label>
            <input type="text" class="form-control" id="name" name="name" value="{{ $package->name }}" required>
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="number" class="form-control" id="price" name="price" step="0.01" value="{{ $package->price }}" required>
        </div>
        <div class="form-group">
            <label for="transportprice">TRansport Price:</label>
            <input type="number" class="form-control" id="transportprice" name="transportprice" step="0.01" value="{{ $package->transportprice }}" required>
        </div> 
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea class="form-control" id="description" name="description" rows="4" required>{{ $package->description }}</textarea>
        </div>
        <div class="form-group">
            <label for="image">Update Image:</label>
            <input type="file" class="form-control" id="image" name="image" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary">Update package Details</button>
    </form>
</div>


    @push('scripts')

@endpush
@endsection
 