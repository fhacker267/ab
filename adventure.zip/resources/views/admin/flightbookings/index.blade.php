 

@extends('admin.layouts.app')
 
 @section('title', 'Page Title')
  
 @section('content')
     <div class="container">
     <h1>Flight Bookings Details</h1>
     <table class="table table-striped">
              <thead>
                  <tr>
                  <th>ID</th>
                      <th>Flight Id </th>
                      <th>Passenger Count</th>
                      
                      <th>Country</th>
                      <th>Total Price</th>
                      <th>Contact Name</th>
                      <th>Number</th>
                      <th>Email</th>
                      <th>Address</th>
                       
                       
                      <th>Actions</th>
                  </tr>
              </thead>
              <tbody>
              <tr> @foreach ($flightBookings as $FlightBooking)
              <td>{{ $FlightBooking->id }}</td>
                          <td>{{ $FlightBooking->flight_id }}</td>
                          <td>{{ $FlightBooking->passenger_count }}</td>
                           
                          <td>{{ $FlightBooking->country }}</td>
                          <td>{{ $FlightBooking->total_price }}</td>
                          <td>{{ $FlightBooking->contact_name }}</td>
                          
                          <td>{{ $FlightBooking->contact_phone_number }}</td>
                          <td>{{ $FlightBooking->contact_email }}</td>
                          <td>{{ $FlightBooking->contact_address }}</td>
                           
                          <td>
                          <form style="display: inline-block;" action="{{ url('admin/flightbookings', $FlightBooking->id) }}" method="POST">
                            @csrf
                            @method('DELETE')

                        <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this flight detail?')">
                            <i class="fa fa-trash"></i> Delete
                        </button>
                    </form>


   
    </td></td>
  </tr>
                 @endforeach
             </tbody>
         </table>
     </div>
 
 @push('scripts')
 
 @endpush
 @endsection
  