
@extends('admin.layouts.app')
 
@section('title', 'Page Title')
 
@section('content')
    <div class="container">
        <h1 class="mb-4">All Flights</h1>
         <table class="table table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Subject</th>
                    <th>Message</th>
                    <th>Actions</th>
                    </tr>
            </thead>
            <tbody>
            @foreach ($contactForms as $contactForm)
                <tr>
                    <td>{{ $contactForm->name }}</td>
                    <td>{{ $contactForm->email }}</td>
                    <td>{{ $contactForm->subject }}</td>
                    <td>{{ $contactForm->message }}</td>
                 
                

                <td>  <form action="{{ url('admin/contact', ['contactForm' => $contactForm->id]) }}" method="POST">
                                  @csrf
                                  @method('DELETE')
                                  <input type="hidden" value="{{ $contactForm->id }}" name="id">
                                  <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this flight?')">
        <i class="fa fa-trash"></i>
    </button>
                              </form></td>  </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    </div>
    </div>
    
@push('scripts')

@endpush
@endsection
 