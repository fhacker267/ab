

@extends('admin.layouts.app')
 
@section('title', 'Page Title')
 
@section('content')
   
<div class="container">
    <h1>Edit Flight</h1>
    <!-- <a href="flights/show" class="btn btn-primary">Show All List</a>  -->
    <form action="{{ route('admin.flights.update', ['flight' => $flight->id]) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="country">Country:</label>
            <input type="text" class="form-control" id="country" name="country" value="{{ $flight->country }}" required>
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="number" class="form-control" id="price" name="price" step="0.01" value="{{ $flight->price }}" required>
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea class="form-control" id="description" name="description" rows="4" required>{{ $flight->description }}</textarea>
        </div>
        <div class="form-group">
            <label for="image">Update Image:</label>
            <input type="file" class="form-control" id="image" name="image" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary">Update Flight</button>
    </form>
</div>


    @push('scripts')

@endpush
@endsection
 