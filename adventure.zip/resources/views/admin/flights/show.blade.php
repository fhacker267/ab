<!-- resources/views/flights/index.blade.php -->

@extends('admin.layouts.app')
 
@section('title', 'Page Title')
 
@section('content')
    <div class="container">
        <h1 class="mb-4">All Flights</h1>
         <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Country</th>
                    <th>Price</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($flights as $flight)
                    <tr>
                        <td>{{ $flight->id }}</td>
                        <td>{{ $flight->country }}</td>
                        <td>{{ $flight->price }}</td>
                        <td style="word-wrap: break-word; white-space: initial;">{{ $flight->description }}</td>
                        <td>
    <img src="{{ asset('storage/' . $flight->image_path) }}" alt="Flight Image" style="max-width: 100px; border-radius: 10px;">
</td>
<td>
    <form style="display: inline-block;" action="{{ url('admin/flights', ['flight' => $flight->id]) }}" method="POST">
        @csrf
        @method('DELETE')

        <input type="hidden" value="{{ $flight->id }}" name="id">

        <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this flight?')">
            <i class="fa fa-trash"></i> Delete
        </button>
    </form>
    
    <form style="display: inline-block;" action="{{ route('admin.flights.edit', ['flight' => $flight->id]) }}" method="GET">
        @csrf
        <button type="submit" class="btn btn-link">
            <i class="fa fa-pencil fa-fw"></i> Edit
        </button>
    </form>
</td>

                                  </tr>
                @endforeach
            </tbody>
        </table>
    </div>
  

@push('scripts')

@endpush
@endsection
 