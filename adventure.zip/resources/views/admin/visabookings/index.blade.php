 

@extends('admin.layouts.app')
 
 @section('title', 'Page Title')
  
 @section('content')
     <div class="container">
     <h1>Visas Booking  Details</h1>
     <table class="table table-striped">
              <thead>
                  <tr>
                  <th>ID</th>
                      <th>Visa Id </th>
                      <th>Passenger Count</th>
                      
                      <th>Country</th>
                      <th>Total Price</th>
                      <th>Contact Name</th>
                      <th>Number</th>
                      <th>Email</th>
                      <th>Address</th>
                       
                       
                      <th>Actions</th>
                  </tr>
              </thead>
              <tbody>
              <tr> @foreach ($visaBookings as $VisaBooking)
              <td>{{ $VisaBooking->id }}</td>
                          <td>{{ $VisaBooking->visa_id }}</td>
                          <td>{{ $VisaBooking->passenger_count }}</td>
                           
                          <td>{{ $VisaBooking->country }}</td>
                          <td>{{ $VisaBooking->total_price }}</td>
                          <td>{{ $VisaBooking->contact_name }}</td>
                          
                          <td>{{ $VisaBooking->contact_phone_number }}</td>
                          <td>{{ $VisaBooking->contact_email }}</td>
                          <td>{{ $VisaBooking->contact_address }}</td>
                           
                          <td>
                          <form style="display: inline-block;" action="{{ url('admin/visabookings', $VisaBooking->id) }}" method="POST">
    @csrf
    @method('DELETE')

    <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this package detail?')">
        <i class="fa fa-trash"></i> Delete
    </button>
</form>


   
    </td></td>
  </tr>
                 @endforeach
             </tbody>
         </table>
     </div>
 
 @push('scripts')
 
 @endpush
 @endsection
  