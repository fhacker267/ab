

@extends('admin.layouts.app')
 
@section('title', 'Page Title')
 
@section('content')
   
<div class="container">
    <h1>Edit Flight</h1>
    <form action="{{ route('admin.visas.update', ['visa' => $visa->id]) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="country">Country :</label>
            <input type="text" class="form-control" id="country" name="country" value="{{ $visa->country }}" required>
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="number" class="form-control" id="price" name="price" step="0.01" value="{{ $visa->price }}" required>
        </div>
        <div class="form-group">
    <label for="date">Date:</label>
    <input type="date" class="form-control" id="date" name="date" value="{{ $visa->date }}" required>
</div>
        <div class="form-group">
            <label for="image">Update Image:</label>
            <input type="file" class="form-control" id="image" name="image" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary">Update Visa</button>
    </form>
</div>


    @push('scripts')

@endpush
@endsection
 