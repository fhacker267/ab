 

@extends('admin.layouts.app')
 
@section('title', 'Page Title')
 
@section('content')
    <div class="container">
        <h1 class="mb-4">All hotels details</h1>
         <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($hotels as $hotel)
                    <tr>
                        <td>{{ $hotel->id }}</td>
                        <td>{{ $hotel->name }}</td>
                        <td>{{ $hotel->price }}</td>
                        <td style="word-wrap: break-word; white-space: initial;">{{ $hotel->description }}</td>
                        <td>
    <img src="{{ asset('storage/' . $hotel->image_path) }}" alt="hotel Image" style="max-width: 100px; border-radius: 10px;">
</td>
<td>
    <form style="display: inline-block;" action="{{ url('admin/hotels', ['hotel' => $hotel->id]) }}" method="POST">
        @csrf
        @method('DELETE')

        <input type="hidden" value="{{ $hotel->id }}" name="id">

        <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this hotel detail?')">
            <i class="fa fa-trash"></i> Delete
        </button>
    </form>
    
    <form style="display: inline-block;" action="{{ route('admin.hotels.edit', ['hotel' => $hotel->id]) }}" method="GET">
        @csrf
        <button type="submit" class="btn btn-link">
            <i class="fa fa-pencil fa-fw"></i> Edit
        </button>
    </form>
</td>
  </tr>
                @endforeach
            </tbody>
        </table>
    </div>
  

@push('scripts')

@endpush
@endsection
 