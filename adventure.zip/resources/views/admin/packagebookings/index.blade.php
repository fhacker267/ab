 

@extends('admin.layouts.app')
 
 @section('title', 'Page Title')
  
 @section('content')
     <div class="container">
     <h1>Package Bookings Details</h1>
     <table class="table table-striped">
              <thead>
                  <tr>
                  <th>ID</th>
                      <th>Package Id </th>
                      <th>Passenger Count</th>
                      <th>Transport Option </th>
                      <th>Transport Passenger</th>
                      <th>Total Price</th>
                      <th>Contact Name</th>
                      <th>Number</th>
                      <th>Email</th>
                      <th>Address</th>
                       
                       
                      <th>Actions</th>
                  </tr>
              </thead>

              <tbody>
              <tr> @foreach ($packageBookings as $PackageBooking)
              <td>{{ $PackageBooking->id }}</td>
                          <td>{{ $PackageBooking->package_id }}</td>
                          <td>{{ $PackageBooking->passenger_count }}</td>
                          @if($PackageBooking->transport_option == 1)
                          <td>Yes</td>
                          @else
                          <td>No</td>
                          @endif

                          <td>{{ $PackageBooking->transport_passengers }}</td>
                          <td>{{ $PackageBooking->total_price }}</td>
                          <td>{{ $PackageBooking->contact_name }}</td>
                          
                          <td>{{ $PackageBooking->contact_phone_number }}</td>
                          <td>{{ $PackageBooking->contact_email }}</td>
                          <td>{{ $PackageBooking->contact_address }}</td>
                           
                          <td>
                          <form style="display: inline-block;" action="{{ url('admin/packagebookings', $PackageBooking->id) }}" method="POST">
    @csrf
    @method('DELETE')

    <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this package detail?')">
        <i class="fa fa-trash"></i> Delete
    </button>
</form>


   
    </td></td>
  </tr>
                 @endforeach
             </tbody>
         </table>
     </div>
 
 @push('scripts')
 
 @endpush
 @endsection
  