
 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php $__env->startSection('content'); ?>
<main>
    <div class="container mt-5">
        <h1>WhatsApp Numbers</h1>
        
        <form action="<?php echo e(route('admin.whatsappnumbers.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <!-- <label for="number">Enter WhatsApp Number:</label>
            <input type="number" name="number" id="number" required>
            <button type="submit">Add Number</button> -->
        </form>
        
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Number</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $whatsAppNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $whatsAppNumber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($whatsAppNumber->id); ?></td>
                    <td><?php echo e($whatsAppNumber->number); ?></td>
                    <td>
                        <form style="display: inline-block;" action="<?php echo e(route('admin.whatsappnumbers.edit', $whatsAppNumber->id)); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-link">
                                <i class="fa fa-pencil fa-fw"></i> Edit
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</main>
 
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adventure\resources\views/admin/whatsappnumbers/index.blade.php ENDPATH**/ ?>