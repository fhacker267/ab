


 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php $__env->startSection('content'); ?>
   
<div class="container">
<h1>Edit WhatsApp Number</h1>

<form action="<?php echo e(route('admin.whatsappnumbers.update', $whatsAppNumber->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <label for="number">Edit WhatsApp Number:</label>
    <input type="number" name="number" id="number" value="<?php echo e($whatsAppNumber->number); ?>" required>
    <button type="submit">Save Changes</button>
</form>
</div>


    <?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adventure\resources\views/admin/whatsappnumbers/edit.blade.php ENDPATH**/ ?>