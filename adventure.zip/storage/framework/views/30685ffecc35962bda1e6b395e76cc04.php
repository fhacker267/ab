 


 
 <?php $__env->startSection('title', 'Page Title'); ?>
  
 <?php $__env->startSection('content'); ?>
     <div class="container">
     <h1>Visas Booking  Details</h1>
     <table class="table table-striped">
              <thead>
                  <tr>
                  <th>ID</th>
                      <th>Visa Id </th>
                      <th>Passenger Count</th>
                      
                      <th>Country</th>
                      <th>Total Price</th>
                      <th>Contact Name</th>
                      <th>Number</th>
                      <th>Email</th>
                      <th>Address</th>
                       
                       
                      <th>Actions</th>
                  </tr>
              </thead>
              <tbody>
              <tr> <?php $__currentLoopData = $visaBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisaBooking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <td><?php echo e($VisaBooking->id); ?></td>
                          <td><?php echo e($VisaBooking->visa_id); ?></td>
                          <td><?php echo e($VisaBooking->passenger_count); ?></td>
                           
                          <td><?php echo e($VisaBooking->country); ?></td>
                          <td><?php echo e($VisaBooking->total_price); ?></td>
                          <td><?php echo e($VisaBooking->contact_name); ?></td>
                          
                          <td><?php echo e($VisaBooking->contact_phone_number); ?></td>
                          <td><?php echo e($VisaBooking->contact_email); ?></td>
                          <td><?php echo e($VisaBooking->contact_address); ?></td>
                           
                          <td>
                          <form style="display: inline-block;" action="<?php echo e(url('admin/visabookings', $VisaBooking->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>

    <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this package detail?')">
        <i class="fa fa-trash"></i> Delete
    </button>
</form>


   
    </td></td>
  </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
         </table>
     </div>
 
 <?php $__env->startPush('scripts'); ?>
 
 <?php $__env->stopPush(); ?>
 <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adventure\resources\views/admin/visabookings/index.blade.php ENDPATH**/ ?>