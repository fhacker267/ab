
 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php $__env->startSection('content'); ?>
 <main>
 <div class="container mt-5">
        <h1 class="mb-4">Visas</h1>
        <a href="visas/show" class="btn btn-primary">Show All List</a>
    
        <form method="post" action="<?php echo e(route('visas.store')); ?>" enctype="multipart/form-data">
 <?php echo e(csrf_field()); ?>

        <div class="form-group">
                <label for="country">Country  :</label>
                <input type="text"   value=" "  class="form-control" id="country" name="country"   required> 
            </div>
             

            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number"  value=" "  class="form-control" id="price" name="price" step="0.01" required>
            </div>

            <div class="form-group">
    <label for="date">Date:</label>
    <input type="date" class="form-control" id="date" name="date" required>
</div>

            <div class="form-group">
                <label for="image">Select an image to upload:</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>




</main>

 
 
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adventure\resources\views/admin/visas/index.blade.php ENDPATH**/ ?>