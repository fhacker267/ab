

 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-4">All Flights</h1>
         <table class="table table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Subject</th>
                    <th>Message</th>
                    <th>Actions</th>
                    </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $contactForms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contactForm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($contactForm->name); ?></td>
                    <td><?php echo e($contactForm->email); ?></td>
                    <td><?php echo e($contactForm->subject); ?></td>
                    <td><?php echo e($contactForm->message); ?></td>
                 
                

                <td>  <form action="<?php echo e(url('admin/contact', ['contactForm' => $contactForm->id])); ?>" method="POST">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('DELETE'); ?>
                                  <input type="hidden" value="<?php echo e($contactForm->id); ?>" name="id">
                                  <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this flight?')">
        <i class="fa fa-trash"></i>
    </button>
                              </form></td>  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div>
    </div>
    
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adventure\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>