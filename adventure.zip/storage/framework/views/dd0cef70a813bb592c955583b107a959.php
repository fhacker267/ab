 


 
 <?php $__env->startSection('title', 'Page Title'); ?>
  
 <?php $__env->startSection('content'); ?>
     <div class="container">
     <h1>Flight Bookings Details</h1>
     <table class="table table-striped">
              <thead>
                  <tr>
                  <th>ID</th>
                      <th>Flight Id </th>
                      <th>Passenger Count</th>
                      
                      <th>Country</th>
                      <th>Total Price</th>
                      <th>Contact Name</th>
                      <th>Number</th>
                      <th>Email</th>
                      <th>Address</th>
                       
                       
                      <th>Actions</th>
                  </tr>
              </thead>
              <tbody>
              <tr> <?php $__currentLoopData = $flightBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FlightBooking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <td><?php echo e($FlightBooking->id); ?></td>
                          <td><?php echo e($FlightBooking->flight_id); ?></td>
                          <td><?php echo e($FlightBooking->passenger_count); ?></td>
                           
                          <td><?php echo e($FlightBooking->country); ?></td>
                          <td><?php echo e($FlightBooking->total_price); ?></td>
                          <td><?php echo e($FlightBooking->contact_name); ?></td>
                          
                          <td><?php echo e($FlightBooking->contact_phone_number); ?></td>
                          <td><?php echo e($FlightBooking->contact_email); ?></td>
                          <td><?php echo e($FlightBooking->contact_address); ?></td>
                           
                          <td>
                          <form style="display: inline-block;" action="<?php echo e(url('admin/flightbookings', $FlightBooking->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>

    <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this flight detail?')">
        <i class="fa fa-trash"></i> Delete
    </button>
</form>


   
    </td></td>
  </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
         </table>
     </div>
 
 <?php $__env->startPush('scripts'); ?>
 
 <?php $__env->stopPush(); ?>
 <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adventure\resources\views/admin/flightBookings/index.blade.php ENDPATH**/ ?>