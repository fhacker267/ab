


 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php $__env->startSection('content'); ?>
   
<div class="container">
    <h1>Edit Flight</h1>
    <form action="<?php echo e(route('admin.visas.update', ['visa' => $visa->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="country">Country :</label>
            <input type="text" class="form-control" id="country" name="country" value="<?php echo e($visa->country); ?>" required>
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="number" class="form-control" id="price" name="price" step="0.01" value="<?php echo e($visa->price); ?>" required>
        </div>
        <div class="form-group">
    <label for="date">Date:</label>
    <input type="date" class="form-control" id="date" name="date" value="<?php echo e($visa->date); ?>" required>
</div>
        <div class="form-group">
            <label for="image">Update Image:</label>
            <input type="file" class="form-control" id="image" name="image" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary">Update Visa</button>
    </form>
</div>


    <?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adventure\resources\views/admin/visas/edit.blade.php ENDPATH**/ ?>