


 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php $__env->startSection('content'); ?>
   
<div class="container">
    <h1>Edit Flight</h1>
    <form action="<?php echo e(route('admin.packages.update', ['package' => $package->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name">name:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($package->name); ?>" required>
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="number" class="form-control" id="price" name="price" step="0.01" value="<?php echo e($package->price); ?>" required>
        </div>
        <div class="form-group">
            <label for="transportprice">TRansport Price:</label>
            <input type="number" class="form-control" id="transportprice" name="transportprice" step="0.01" value="<?php echo e($package->transportprice); ?>" required>
        </div> 
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea class="form-control" id="description" name="description" rows="4" required><?php echo e($package->description); ?></textarea>
        </div>
        <div class="form-group">
            <label for="image">Update Image:</label>
            <input type="file" class="form-control" id="image" name="image" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary">Update package Details</button>
    </form>
</div>


    <?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adventure\resources\views/admin/packages/edit.blade.php ENDPATH**/ ?>