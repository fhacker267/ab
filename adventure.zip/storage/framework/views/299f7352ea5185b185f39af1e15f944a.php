 


 
 <?php $__env->startSection('title', 'Page Title'); ?>
  
 <?php $__env->startSection('content'); ?>
     <div class="container">
         <h1 class="mb-4">All packages details</h1>
          <table class="table table-striped">
             <thead>
                 <tr>
                     <th>ID</th>
                     <th>Name</th>
                     <th>Price</th>
                     <th>Transport Price</th>
                     <th>Description</th>
                     <th>Image</th>
                     <th>Actions</th>
                 </tr>
             </thead>
             <tbody>
                 <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                         <td><?php echo e($package->id); ?></td>
                         <td><?php echo e($package->name); ?></td>
                         <td><?php echo e($package->price); ?></td>
                         <td><?php echo e($package->transportprice); ?></td>
                         <td style="word-wrap: break-word; white-space: initial;"><?php echo e($package->description); ?></td>
                         <td>
     <img src="<?php echo e(asset('storage/' . $package->image_path)); ?>" alt="package Image" style="max-width: 100px; border-radius: 10px;">
 </td>
 <td>
    <form style="display: inline-block;" action="<?php echo e(url('admin/packages', ['package' => $package->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <input type="hidden" value="<?php echo e($package->id); ?>" name="id">

        <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this package detail?')">
            <i class="fa fa-trash"></i> Delete
        </button>
    </form>
    
    <form style="display: inline-block;" action="<?php echo e(route('admin.packages.edit', ['package' => $package->id])); ?>" method="GET">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-link">
            <i class="fa fa-pencil fa-fw"></i> Edit
        </button>
    </form>
</td>
  </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
         </table>
     </div>
   
 
 <?php $__env->startPush('scripts'); ?>
 
 <?php $__env->stopPush(); ?>
 <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adventure\resources\views/admin/packages/show.blade.php ENDPATH**/ ?>