<!-- resources/views/flights/index.blade.php -->


 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-4">All Flights</h1>
         <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Country</th>
                    <th>Price</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($flight->id); ?></td>
                        <td><?php echo e($flight->country); ?></td>
                        <td><?php echo e($flight->price); ?></td>
                        <td style="word-wrap: break-word; white-space: initial;"><?php echo e($flight->description); ?></td>
                        <td>
    <img src="<?php echo e(asset('storage/' . $flight->image_path)); ?>" alt="Flight Image" style="max-width: 100px; border-radius: 10px;">
</td>
<td>
    <form style="display: inline-block;" action="<?php echo e(url('admin/flights', ['flight' => $flight->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <input type="hidden" value="<?php echo e($flight->id); ?>" name="id">

        <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this flight?')">
            <i class="fa fa-trash"></i> Delete
        </button>
    </form>
    
    <form style="display: inline-block;" action="<?php echo e(route('admin.flights.edit', ['flight' => $flight->id])); ?>" method="GET">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-link">
            <i class="fa fa-pencil fa-fw"></i> Edit
        </button>
    </form>
</td>

                                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
  

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adventure\resources\views/admin/flights/show.blade.php ENDPATH**/ ?>