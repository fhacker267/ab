 


 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-4">All hotels details</h1>
         <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($hotel->id); ?></td>
                        <td><?php echo e($hotel->name); ?></td>
                        <td><?php echo e($hotel->price); ?></td>
                        <td style="word-wrap: break-word; white-space: initial;"><?php echo e($hotel->description); ?></td>
                        <td>
    <img src="<?php echo e(asset('storage/' . $hotel->image_path)); ?>" alt="hotel Image" style="max-width: 100px; border-radius: 10px;">
</td>
<td>
    <form style="display: inline-block;" action="<?php echo e(url('admin/hotels', ['hotel' => $hotel->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <input type="hidden" value="<?php echo e($hotel->id); ?>" name="id">

        <button type="submit" class="btn btn-link" onclick="return confirm('Are you sure you want to delete this hotel detail?')">
            <i class="fa fa-trash"></i> Delete
        </button>
    </form>
    
    <form style="display: inline-block;" action="<?php echo e(route('admin.hotels.edit', ['hotel' => $hotel->id])); ?>" method="GET">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-link">
            <i class="fa fa-pencil fa-fw"></i> Edit
        </button>
    </form>
</td>
  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
  

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adventure\resources\views/admin/hotels/show.blade.php ENDPATH**/ ?>